package Game;

import java.util.List;

import GameEngine.IBehaviour;
import GameEngine.IGameObject;
import GameEngine.InputEvent;

public class Player implements IBehaviour {
    private Health healthManager;
    private StateMachine stateMachine;
    private float score;
    private IGameObject go;

    public Player(Health health, StateMachine stateMachine) {
        this.healthManager = health;
        this.stateMachine = stateMachine;
        this.score = 0;
    }

    @Override
    public IGameObject gameObject() {
        return go;
    }

    @Override
    public void gameObject(IGameObject go) {
        this.go = go;
    }

    @Override
    public void onUpdate(double dT, InputEvent ie) {
        go.update(); // Updates position and colliders essencially
        stateMachine.onUpdate(dT, ie); // Updates what the player does
    }

    @Override
    public void onCollision(List<IGameObject> gol) {

    }

    @Override
    public void onInit() {

    }

    @Override
    public void onEnabled() {

    }

    @Override
    public void onDisabled() {

    }

    @Override
    public void onDestroy() {

    }

    public void addScore(float score) {
        this.score += score;
    }
    public float getScore() {
        return score;
    }
    public Health getHealthManager() {
        return healthManager;
    }
    public StateMachine getStateMachine() {
        return stateMachine;
    }
}
