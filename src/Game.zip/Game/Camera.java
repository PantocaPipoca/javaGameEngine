package Game;

import GameEngine.GameObject;

public class Camera {

    private GameObject target;

    public void setTarget(GameObject target) {
        this.target = target;
    }
}
