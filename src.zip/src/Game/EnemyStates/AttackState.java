package Game.EnemyStates;

import Game.State;
import GameEngine.IGameObject;
import GameEngine.InputEvent;


public class AttackState extends State {
    
    public AttackState() {

    }

    @Override
    public void onUpdate(double dT, InputEvent ie) {

    }

    @Override
    public void onEnter() {

    }

    @Override
    public void onExit() {

    }

    @Override
    public void onCollision(IGameObject other) {

    }

}
