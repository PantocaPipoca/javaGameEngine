package Game;

import java.util.List;

public class RoomLoader {
    
    public List<Room> loadAll() {
        return null;
    }
}
