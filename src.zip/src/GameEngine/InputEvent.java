package GameEngine;

public class InputEvent {

}
